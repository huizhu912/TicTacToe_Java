import java.util.Arrays;

class printNumWinSet {
	public printNumWinSet() {
		for (int[] array : checkGameState.numWinSet) {
			System.out.println(Arrays.toString(array));
		}
	}
}